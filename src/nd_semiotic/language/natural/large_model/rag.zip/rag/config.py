from pathlib import Path


class Config:
    def __init__(self):
        self.repo_roots = [
            "/home/donkarlo/Dropbox/repo",
        ]

        self.embedding_model_path = "/home/donkarlo/Dropbox/repo/nd_semiotic_project/data/language/natural/larg_model/nomic-embed-text-v1.5.Q2_K.gguf"
        self.chat_model_path = "/home/donkarlo/Dropbox/repo/nd_semiotic_project/data/language/natural/larg_model/qwen2.5-3b-instruct-q4_k_m.gguf"

        self.cache_dir = "/home/donkarlo/Dropbox/repo/nd_semiotic_project/data/language/natural/larg_model/chache"

        self.allowed_extensions = [".yaml", ".yml", ".md", ".txt", ".tex"]
        self.ignored_directories = [".git", "__pycache__", ".venv", "venv", "node_modules", "build", "dist", "out"]

        self.chunk_size_chars = 1200
        self.chunk_overlap_chars = 200

        self.top_k = 8
        self.max_context_chunks = 8

        self.chat_n_ctx = 4096
        self.chat_max_tokens = 256
        self.chat_temperature = 0.2
        self.chat_top_p = 0.95
        self.chat_repeat_penalty = 1.15
        self.n_threads = 8

        self.embedding_n_ctx = 512
        self.embedding_batch_size = 8

    def get_cache_dir_path(self) -> Path:
        return Path(self.cache_dir)

    def get_index_path(self) -> Path:
        return self.get_cache_dir_path() / "faiss.index"

    def get_chunks_path(self) -> Path:
        return self.get_cache_dir_path() / "chunks.jsonl"
