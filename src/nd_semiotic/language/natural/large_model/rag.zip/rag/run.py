from nd_semiotic.language.natural.large_model.rag.config import Config
from nd_semiotic.language.natural.large_model.rag.rag import Rag


class RagTerminalApp:
    def __init__(self):
        self._rag = Rag(Config())

    def run(self) -> None:
        self._rag.build_or_load()
        print("RAG terminal ready.")
        print("Type your question and press Enter. Type :exit to quit.")
        while True:
            question = input("Question: ").strip()
            if not question:
                continue
            if question == ":exit":
                break
            reply = self._rag.get_reply(question)
            print(reply)


def main():
    RagTerminalApp().run()


if __name__ == "__main__":
    main()
